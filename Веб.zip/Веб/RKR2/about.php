<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>О нас - Интернет-магазин электроники</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <main>
        <div class="container">
            <h1>О нашем магазине</h1>
            
            <section class="about-content-full">
                <div class="about-section-block">
                    <h2>Наша история</h2>
                    <p>Мы начали свою деятельность в 2020 году с целью предоставить покупателям качественную электронику по доступным ценам. За годы работы мы завоевали доверие тысяч клиентов и стали одним из ведущих интернет-магазинов в регионе.</p>
                </div>
                
                <div class="about-section-block">
                    <h2>Наши преимущества</h2>
                    <div class="advantages-grid">
                        <div class="advantage-card">
                            <h3>🎯 Широкий ассортимент</h3>
                            <p>Более 1000 товаров от проверенных производителей</p>
                        </div>
                        <div class="advantage-card">
                            <h3>💰 Выгодные цены</h3>
                            <p>Регулярные акции и специальные предложения</p>
                        </div>
                        <div class="advantage-card">
                            <h3>🚚 Быстрая доставка</h3>
                            <p>Доставка по всей стране в течение 1-3 дней</p>
                        </div>
                        <div class="advantage-card">
                            <h3>🛡️ Гарантия качества</h3>
                            <p>Официальная гарантия на всю продукцию</p>
                        </div>
                        <div class="advantage-card">
                            <h3>💬 Поддержка 24/7</h3>
                            <p>Круглосуточная служба поддержки клиентов</p>
                        </div>
                        <div class="advantage-card">
                            <h3>🔒 Безопасная оплата</h3>
                            <p>Различные способы оплаты, защита данных</p>
                        </div>
                    </div>
                </div>
                
                <div class="about-section-block">
                    <h2>Наша команда</h2>
                    <p>Мы - команда профессионалов, которые любят свою работу и всегда готовы помочь вам выбрать идеальное устройство. Наши консультанты имеют многолетний опыт работы с техникой и помогут разобраться во всех нюансах.</p>
                </div>
                
                <div class="about-section-block">
                    <h2>Контакты</h2>
                    <div class="contact-info">
                        <p><strong>Адрес:</strong> г. Москва, ул. Примерная, д. 1</p>
                        <p><strong>Телефон:</strong> +7 (495) 123-45-67</p>
                        <p><strong>Email:</strong> info@shop.ru</p>
                        <p><strong>Режим работы:</strong> Пн-Вс: 9:00 - 21:00</p>
                    </div>
                </div>
            </section>
        </div>
    </main>
    
    <?php include 'includes/footer.php'; ?>
</body>
</html>

